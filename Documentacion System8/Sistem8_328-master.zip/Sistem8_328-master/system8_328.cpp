#include <system8_328.h>
#include <arduino.h>
#include <avr/io.h>

/*void SYSTEM8::iniciarSistema()
{
 /*pinMode(13, OUTPUT);
  //SYSTEM8::emptyT = new SYSTEM8::Task(SYSTEM8::emptyF, 128);

  stack_addr = &SYSTEM8::emptyStack;

  // Inicializar el Timmer en modo CTC (Cuenta cilcica ascendente)
  TCCR0A |= (1 << WGM01);

  // Configurar el valor con el que se desea realizar el conteo
  OCR0A = 0xF9;

  TIMSK0 |= (1 << OCIE0A);    //Servicio de Rutinas de Interrumcion 

  E         //Activar Interrupciones

  TCCR0B |= (1 << CS01) | (1 << CS00);
  // Configurar el prescaler a 64 e inicializar el timer
}*/

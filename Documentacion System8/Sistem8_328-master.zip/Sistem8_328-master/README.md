# Sistem8_328
sistema configurado para utilizar el microcontrolador ATMEGA328P
